package UniversityCup.src;

public class Shape {
    public int id;
    public int box;
    public int capacity;
    public int quant = 0;
    public int [][] or0;
    public int [][] or1;
    public int [][] or2;
    public int [][] or3;

    public Shape(int id, int box, int capacity, int [][] or0, int [][] or1, int [][] or2, int [][] or3){
        this.id = id;
        this.box = box;
        this.capacity = capacity;
        this.or0 = or0;
        this.or1 = or1;
        this.or2 = or2;
        this.or3 = or3;
        
    }



    
}